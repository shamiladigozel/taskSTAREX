<!doctype html>
<html lang="az">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin</title>
</head>
<body>
<form id="form_pr" action="<?php echo e(route('admin')); ?>" method="POST" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>
    <label>Product name:</label>  <input name="pr_name" type="text"/></br>
    <label>Product price:</label> <input name="pr_price" type="text"/></br>
    <label>Image select:</label> <input type="file" name="pr_file"/></br>
    <input id="inp_sort" type="hidden" name="sort">
    <input id="inp_kategoriya" type="hidden" name="kategoria">
    <label>Kategoriya:</label>
    <select id="kategoriya">
        <option selected="selected" value="elektronika">Elektronika</option>
        <option value="geyimler">Geyimler</option>

    </select></br>
    <select id="sort">
        <option selected="selected" value="a">Komputerler</option>
        <option value="b">Printerler</option>
        <option value="c"> Telefon&Telefon aksesusarlari</option>
        <option value="d">Qadin geyimleri</option>
        <option value="e">Kisi geyimleri</option>
        <option value="f">Usaq geyimleri</option>
    </select>
    </br>
     <button onclick="Upload()" type="button">Upload</button>
</form>
<script>
    function Upload() {
     document.getElementById('inp_sort').value=document.getElementById('sort').value;
     document.getElementById('inp_kategoriya').value=document.getElementById('kategoriya').value;
        document.getElementById('form_pr').submit();
    }
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Laravel\STAREX_task\resources\views/Admin/index.blade.php ENDPATH**/ ?>