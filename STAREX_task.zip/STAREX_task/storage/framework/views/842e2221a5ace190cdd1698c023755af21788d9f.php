
<nav class="navbar is-fixed-top" role="navigation" aria-label="main navigation">

    <div class="navbar-brand">

            <img src="<?php echo e(asset('logo.png')); ?>" width="112" height="28">


        <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
        </a>
    </div>

    <div id="navbarBasicExample" class="navbar-menu">
        <div class="navbar-start">
            <div class="navbar-item has-dropdown is-hoverable">
                <a class="navbar-link">
                    Elektronika
                </a>

                <div class="navbar-dropdown">
                    <a class="navbar-item">
                        Komputerler
                    </a>
                    <a class="navbar-item">
                        Printerler
                    </a>
                    <a class="navbar-item">
                        Telefon&Telefon aksesusarlari
                    </a>


                </div>
            </div>

            <div class="navbar-item has-dropdown is-hoverable">
                <a class="navbar-link">
                    Geyimler
                </a>

                <div class="navbar-dropdown">
                    <a class="navbar-item">
                        Qadin geyimleri
                    </a>
                    <a class="navbar-item">
                        Kisi geyimleri
                    </a>
                    <a class="navbar-item">
                        Usaq geyimleri
                    </a>

                </div>
            </div>


        </div>

        <div class="navbar-end">
            <div class="navbar-item">
                <div class="buttons">
                    <a class="button is-primary">
                        <strong>Qeydiyyatdan kec</strong>
                    </a>
                    <a class="button is-light">
                        Daxil ol
                    </a>
                </div>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\Laravel\STAREX_task\resources\views/Anasehife/layouts/menu.blade.php ENDPATH**/ ?>