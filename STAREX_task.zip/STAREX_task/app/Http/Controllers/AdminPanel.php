<?php

namespace App\Http\Controllers;

use App\Product;
use Illuminate\Http\Request;

class AdminPanel extends Controller
{
    //
    public function index(){
        return view('Admin.index');
    }
    public function post_index(Request $request){

        Product::addProduct($request->pr_name,$request->pr_price,$request->kategoria,$request->sort,$request->file('pr_file')->getClientOriginalName());
        $request->file('pr_file')->storeAs('public/products_img',$request->file('pr_file')->getClientOriginalName());

        return view('Admin.index');
    }
}
