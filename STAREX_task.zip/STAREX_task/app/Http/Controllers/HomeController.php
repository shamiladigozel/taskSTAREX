<?php

namespace App\Http\Controllers;

use App\Product;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    //
    public function index(){
        $list=Product::listProducts();
        return view('Anasehife.index',[
            'products'=>$list
        ]);
    }
    public function get_chooseItem($id=null){
        $data=Product::chooseItemByID($id);
        return view('Anasehife.products',[
            'p'=>$data
        ]);
    }
}
