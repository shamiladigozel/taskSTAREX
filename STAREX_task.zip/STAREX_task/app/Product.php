<?php


namespace App;


use Illuminate\Support\Facades\DB;


class Product
{
    public static function addProduct($product_name,$product_price,$product_category,$product_sort,$product_path){
            DB::table('products')->insert([
                'product_name'=>$product_name,
                'product_price'=>$product_price,
                'product_sort'=>$product_sort,
                'product_kategoria'=>$product_category,
                'produc_img'=>$product_path
            ]);

    }
    public static function listProducts(){
      return   DB::table('products')->get();
    }
    public static function chooseItemByID($id){
        if(DB::table('products')->where(['id'=>$id])->exists()){
            return DB::table('products')->where(['id'=>$id])->get();
        }
        else{
            return  null;
        }
    }

}
