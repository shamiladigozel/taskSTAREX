<!doctype html>
<html lang="az">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.1/css/bulma.min.css">
    <link rel="stylesheet" href="{{asset('css/App.css')}}">
    <title>STAREX</title>
</head>
<body>
<header class="head-panel">

    @include('Anasehife.layouts.menu')


</header>
<section>


        <div class="columns is-desktop" style="margin: 110px">
            @if(isset($products))

                @foreach($products as $p)

                   <div class="card" style="margin: 10px">
                    <div class="card-image">
                        <figure class="image is-4by3">
                            <img src="{{asset('storage/products_img/'.$p->produc_img)}}">
                        </figure>
                    </div>
                    <div class="card-content">
                        <div class="media">
                            <div class="media-left">

                            </div>
                            <div class="media-content">
                                <p class="title is-4">{{$p->product_price}}$</p>
                                <p class="subtitle is-6">@Starex</p>
                            </div>
                        </div>

                        <div class="content">
                            <a href="{{route('product',[
    'id'=>$p->id
])}}">{{$p->product_name}}</a>
                            <br>
                            <time datetime="2016-1-1">11:09 PM - 04 feb 2021</time>
                        </div>
                    </div>
                </div>



                @endforeach


            @endif
        </div>



</section>

@include('Anasehife.layouts.footer')


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="{{asset('js/script.js')}}"></script>
<script src="{{asset('js/app.js')}}"></script>



</body>
</html>
